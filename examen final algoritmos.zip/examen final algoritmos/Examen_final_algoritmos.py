#para emviar el correo use la misma estructura que en el proyecto
#final, es como mas facil que me hizo y es funcional
#unicamente usando mi contraseña de aplicacion funciona
import tkinter as tk
from tkinter import messagebox, Toplevel, simpledialog, ttk
from openpyxl import Workbook, load_workbook
from openpyxl.utils import get_column_letter
import os
import smtplib
from email.message import EmailMessage
from email.mime.base import MIMEBase
from email import encoders
ARCHIVO_EXCEL = 'libros.xlsx'
NOMBRE_HOJA = 'Inventario'
COLUMNAS = ["ISBN", "Título", "Autor", "Año", "Cantidad"]
def inicializar_excel():
    """Crea el archivo Excel con las columnas si no existe."""
    if not os.path.exists(ARCHIVO_EXCEL):
        wb = Workbook()
        ws = wb.active
        ws.title = NOMBRE_HOJA
        ws.append(COLUMNAS)
        wb.save(ARCHIVO_EXCEL)

def obtener_libro_por_isbn(isbn, ws):
    """Busca y devuelve la fila de un libro por su ISBN."""
    for i, row in enumerate(ws.iter_rows(min_row=2)):
        if str(row[0].value) == str(isbn):
            return row, i + 2 
    return None, None
def crear_libro(e_isbn, e_titulo, e_autor, e_anio, e_cantidad, ventana):
    """Guarda un nuevo libro en el archivo Excel."""
    isbn = e_isbn.get()
    titulo = e_titulo.get()
    autor = e_autor.get()
    anio = e_anio.get()
    cantidad = e_cantidad.get()

    if not (isbn and titulo and autor and anio and cantidad):
        messagebox.showerror("Error", "Todos los campos son obligatorios")
        return

    try:

        int(isbn)
        int(anio)
        int(cantidad)
    except ValueError:
        messagebox.showerror("Error", "ISBN, Año y Cantidad deben ser números enteros.")
        return

    try:
        if not os.path.exists(ARCHIVO_EXCEL):
            wb = Workbook()
            ws = wb.active
            ws.title = NOMBRE_HOJA
            ws.append(COLUMNAS)
            wb.save(ARCHIVO_EXCEL)
        wb = load_workbook(ARCHIVO_EXCEL)
        if NOMBRE_HOJA not in wb.sheetnames:
            ws = wb.create_sheet(NOMBRE_HOJA)
            ws.append(COLUMNAS)
            wb.save(ARCHIVO_EXCEL)
        ws = wb[NOMBRE_HOJA]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if str(row[0]) == str(isbn):
                messagebox.showerror("Error", f"El ISBN {isbn} ya existe.")
                return
        ws.append([isbn, titulo, autor, anio, cantidad])
        wb.save(ARCHIVO_EXCEL)

        messagebox.showinfo("Éxito", f"Libro '{titulo}' guardado correctamente.")
        e_isbn.delete(0, tk.END)
        e_titulo.delete(0, tk.END)
        e_autor.delete(0, tk.END)
        e_anio.delete(0, tk.END)
        e_cantidad.delete(0, tk.END)

    except Exception as e:
        messagebox.showerror("Error", f"No se pudo guardar el libro: {e}")

def listar_libros():
    """Muestra la lista de libros en una nueva ventana con formato de texto."""
    try:
        wb = load_workbook(ARCHIVO_EXCEL)
        ws = wb[NOMBRE_HOJA]

        ventana = tk.Toplevel(root)
        ventana.title("Inventario de Libros")

        t = tk.Text(ventana, width=80, height=20, font=("Courier", 10))
        t.pack(padx=10, pady=10)
        cabeceras = "\t".join(COLUMNAS)
        t.insert(tk.END, cabeceras + "\n")
        t.insert(tk.END, "-" * (len(cabeceras) + len(COLUMNAS) * 3) + "\n")
        if ws.max_row > 1:
            for row in ws.iter_rows(min_row=2, values_only=True):
                t.insert(tk.END, "\t".join([str(x) for x in row]) + "\n")
        else:
            t.insert(tk.END, "No hay libros en el inventario.")

    except FileNotFoundError:
        messagebox.showerror("Error", "El archivo de inventario no existe.")
    except Exception as e:
        messagebox.showerror("Error", f"Fallo al listar libros: {e}")

def eliminar_libro(e_isbn, ventana):
    """Elimina un libro por su ISBN."""
    isbn = e_isbn.get()
    if not isbn:
        messagebox.showerror("Error", "Ingrese el ISBN del libro a eliminar.")
        return

    try:
        wb = load_workbook(ARCHIVO_EXCEL)
        ws = wb[NOMBRE_HOJA]
        
        libro_existente, fila_num = obtener_libro_por_isbn(isbn, ws)
        
        if libro_existente:
            respuesta = messagebox.askyesno(
                "Confirmar Eliminación", 
                f"¿Seguro que quiere eliminar el libro con ISBN {isbn}?"
            )
            
            if respuesta:
                ws.delete_rows(fila_num, 1) 
                wb.save(ARCHIVO_EXCEL)
                messagebox.showinfo("Éxito", f"Libro con ISBN {isbn} eliminado.")
                ventana.destroy()
        else:
            messagebox.showerror("Error", f"El ISBN {isbn} no fue encontrado.")
            
    except Exception as e:
        messagebox.showerror("Error", f"Fallo al eliminar el libro: {e}")

def editar_libro(e_isbn_bus, e_isbn_act, e_titulo, e_autor, e_anio, e_cantidad, ventana):
    """Edita los datos de un libro existente."""
    isbn_buscado = e_isbn_bus.get()
    isbn_nuevo = e_isbn_act.get()
    titulo = e_titulo.get()
    autor = e_autor.get()
    anio = e_anio.get()
    cantidad = e_cantidad.get()
    
    if not (isbn_buscado and isbn_nuevo and titulo and autor and anio and cantidad):
        messagebox.showerror("Error", "Todos los campos son obligatorios.")
        return
        
    try:
        wb = load_workbook(ARCHIVO_EXCEL)
        ws = wb[NOMBRE_HOJA]
        
        libro_fila, fila_num = obtener_libro_por_isbn(isbn_buscado, ws)
        
        if not libro_fila:
            messagebox.showerror("Error", f"El ISBN {isbn_buscado} no fue encontrado.")
            return
        if isbn_buscado != isbn_nuevo:
            libro_duplicado, _ = obtener_libro_por_isbn(isbn_nuevo, ws)
            if libro_duplicado:
                 messagebox.showerror("Error", f"El nuevo ISBN {isbn_nuevo} ya existe.")
                 return
        libro_fila[0].value = isbn_nuevo
        libro_fila[1].value = titulo
        libro_fila[2].value = autor
        libro_fila[3].value = int(anio)
        libro_fila[4].value = int(cantidad)

        wb.save(ARCHIVO_EXCEL)
        messagebox.showinfo("Éxito", f"Libro actualizado correctamente.")
        ventana.destroy()
        
    except ValueError:
        messagebox.showerror("Error", "Año y Cantidad deben ser números enteros válidos.")
    except Exception as e:
        messagebox.showerror("Error", f"Fallo al editar el libro: {e}")

def enviar_inventario():
    """Prepara el archivo Excel para ser enviado por correo electrónico."""
    if not os.path.exists(ARCHIVO_EXCEL):
        messagebox.showerror("Error", "El archivo de inventario no existe para enviar.")
        return

    respuesta = messagebox.askyesno(
        "Confirmar Envío", 
        f"Se enviará el archivo '{ARCHIVO_EXCEL}' por correo. ¿Desea continuar?"
    )
    if respuesta:
        enviar_correo_adjuntos([ARCHIVO_EXCEL])

def enviar_correo_adjuntos(archivos):
    """Abre la ventana para configurar y enviar un correo con archivos adjuntos."""
    ventana = tk.Toplevel(root)
    ventana.title("Enviar Inventario por Correo")

    tk.Label(ventana, text="Servidor SMTP (ej: smtp.gmail.com)").pack(pady=2)
    entry_smtp = tk.Entry(ventana, width=40)
    entry_smtp.insert(0, "smtp.gmail.com")
    entry_smtp.pack()
    
    tk.Label(ventana, text="Puerto (ej: 587)").pack(pady=2)
    entry_puerto = tk.Entry(ventana, width=40)
    entry_puerto.insert(0, "587")
    entry_puerto.pack()
    
    tk.Label(ventana, text="Usuario (correo)").pack(pady=2)
    entry_usuario = tk.Entry(ventana, width=40)
    entry_usuario.pack()
    
    tk.Label(ventana, text="Contraseña/App Password").pack(pady=2)
    entry_pass = tk.Entry(ventana, show='*', width=40)
    entry_pass.pack()
    
    tk.Label(ventana, text="Destinatario").pack(pady=2)
    entry_dest = tk.Entry(ventana, width=40)
    entry_dest.pack()

    def enviar():
        smtp_server = entry_smtp.get()
        puerto = entry_puerto.get()
        usuario = entry_usuario.get()
        clave = entry_pass.get()
        destino = entry_dest.get()
        
        if not (smtp_server and puerto and usuario and clave and destino):
            messagebox.showerror("Error", "Complete todos los campos de correo.")
            return
            
        try:
            puerto = int(puerto)
        except ValueError:
            messagebox.showerror("Error", "Puerto inválido.")
            return
            
        msg = EmailMessage()
        msg['Subject'] = 'Reporte de Inventario de Libros'
        msg['From'] = usuario
        msg['To'] = destino
        msg.set_content('Adjunto el archivo de inventario de libros.')
        for ruta in archivos:
            try:
                with open(ruta, 'rb') as f:
                    data = f.read()
                maintype = 'application'
                subtype = 'vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                filename = os.path.basename(ruta)
                msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=filename)
            except FileNotFoundError:
                messagebox.showerror("Error", f"Archivo no encontrado: {ruta}")
                return
        try:
            with smtplib.SMTP(smtp_server, puerto) as server:
                server.starttls()
                server.login(usuario, clave)
                server.send_message(msg)
            messagebox.showinfo("Enviado", "Correo enviado correctamente.")
            ventana.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al enviar correo. Verifique la configuración y credenciales. Detalle: {e}")

    tk.Button(ventana, text="Enviar Correo", command=enviar, bg='green', fg='white', width=20).pack(pady=10)
def ventana_crear_libro():
    """Abre la ventana para crear un libro."""
    ventana = tk.Toplevel(root)
    ventana.title("Crear Libro")
    labels = ["ISBN (para buscar el libro):", "Título:", "Autor:", "Año:", "Cantidad:"]
    entries = []
    for i, text in enumerate(labels):
        tk.Label(ventana, text=text).grid(row=i, column=0, padx=10, pady=5, sticky='w')
        entry = tk.Entry(ventana, width=30)
        entry.grid(row=i, column=1, padx=10, pady=5)
        entries.append(entry)
    tk.Button(
        ventana,
        text="Guardar Libro",
        command=lambda: crear_libro(entries[0], entries[1], entries[2], entries[3], entries[4], ventana),
        bg='blue',
        fg='white'
    ).grid(row=len(labels), column=0, columnspan=2, pady=10)

def ventana_eliminar_libro():
    """Abre la ventana para eliminar un libro."""
    ventana = tk.Toplevel(root)
    ventana.title("Eliminar Libro")
    
    tk.Label(ventana, text="Ingrese el ISBN del libro a eliminar:").pack(padx=20, pady=10)
    e_isbn = tk.Entry(ventana, width=30)
    e_isbn.pack(padx=20, pady=5)
    
    tk.Button(
        ventana, 
        text="Eliminar", 
        command=lambda: eliminar_libro(e_isbn, ventana),
        bg='red', 
        fg='white'
    ).pack(pady=10)

def ventana_editar_libro():
    """Abre la ventana para editar un libro."""
    ventana = tk.Toplevel(root)
    ventana.title("Editar Libro")
    tk.Label(ventana, text="Buscar por ISBN Actual:").grid(row=0, column=0, padx=10, pady=5, sticky='w')
    e_isbn_bus = tk.Entry(ventana, width=30)
    e_isbn_bus.grid(row=0, column=1, padx=10, pady=5)

    campos = ['Nuevo ISBN:', 'Título:', 'Autor:', 'Año:', 'Cantidad:']
    entries_edit = []

    for i, campo in enumerate(campos):
        tk.Label(ventana, text=campo).grid(row=i + 1, column=0, padx=10, pady=5, sticky='w')
        entry = tk.Entry(ventana, width=30)
        entry.grid(row=i + 1, column=1, padx=10, pady=5)
        entries_edit.append(entry)
        
    def buscar_libro():
        isbn = e_isbn_bus.get()
        if not isbn:
            messagebox.showerror("Error", "Ingrese el ISBN a buscar.")
            return

        try:
            wb = load_workbook(ARCHIVO_EXCEL)
            ws = wb[NOMBRE_HOJA]
            libro_fila, _ = obtener_libro_por_isbn(isbn, ws)
            
            if libro_fila:
                for entry in entries_edit:
                    entry.delete(0, tk.END)
                
                datos = [c.value for c in libro_fila]
                for i, dato in enumerate(datos):
                    entries_edit[i].insert(0, str(dato))
            else:
                messagebox.showinfo("Información", f"Libro con ISBN {isbn} no encontrado.")
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al buscar: {e}")
    tk.Button(ventana, text="Buscar", command=buscar_libro).grid(row=0, column=2, padx=5)
    tk.Button(
        ventana, 
        text="Guardar Cambios", 
        command=lambda: editar_libro(e_isbn_bus, entries_edit[0], entries_edit[1], entries_edit[2], entries_edit[3], entries_edit[4], ventana),
        bg='blue', 
        fg='white'
    ).grid(row=len(campos) + 1, column=0, columnspan=3, pady=10)
def main():
    """Configura la ventana principal y los menús."""
    inicializar_excel()
    
    global root
    root = tk.Tk()
    root.title("Sistema de Mantenimiento de Libros")
    root.geometry("450x300")
    
    tk.Label(root, text="Gestión de Inventario de Libros", font=('Arial', 14, 'bold')).pack(pady=20)
    frame_botones = tk.Frame(root)
    frame_botones.pack(pady=10)
    tk.Button(frame_botones, text="Crear Libro", command=ventana_crear_libro, width=30).pack(pady=5)
    tk.Button(frame_botones, text="Editar Libro", command=ventana_editar_libro, width=30).pack(pady=5)
    tk.Button(frame_botones, text="Eliminar Libro", command=ventana_eliminar_libro, width=30).pack(pady=5)
    tk.Button(frame_botones, text="Listar Libros", command=listar_libros, width=30).pack(pady=5)
    tk.Button(frame_botones, text="Enviar Inventario por Correo", command=enviar_inventario, width=30).pack(pady=5)
    
    root.mainloop()

if __name__ == "__main__":
    main()
