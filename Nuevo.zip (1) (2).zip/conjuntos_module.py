import tkinter as tk
from tkinter import messagebox

def parse_set(text):
    items = [s.strip() for s in text.split(',')]
    clean = []
    for it in items:
        if it == '':
            continue
        try:
            clean.append(int(it))
        except ValueError:
            clean.append(it)
    return set(clean)

def open_conjuntos(parent=None):
    owns_root = parent is None
    root = tk.Tk() if owns_root else tk.Toplevel(parent)
    if owns_root:
        root.title("Conjuntos")
    else:
        root.title("Conjuntos")

    root.geometry("520x200")

    def calcular_conjunto():
        try:
            A = parse_set(entry_a.get())
            B = parse_set(entry_b.get())
        except Exception as e:
            messagebox.showerror("Error", f"Error al leer los conjuntos: {e}")
            return
        op = op_var.get()
        if op == 'union':
            res = A.union(B)
        else:
            res = A.intersection(B)
        resultado_var.set(str(sorted(list(res), key=str)))

    def cerrar():
        root.destroy()

    tk.Label(root, text="Conjunto A:").grid(row=0, column=0, sticky='e', pady=5)
    entry_a = tk.Entry(root, width=30); entry_a.grid(row=0, column=1)
    tk.Label(root, text="Conjunto B:").grid(row=1, column=0, sticky='e', pady=5)
    entry_b = tk.Entry(root, width=30); entry_b.grid(row=1, column=1)

    op_var = tk.StringVar(value='union')
    tk.Radiobutton(root, text="Unión", variable=op_var, value='union').grid(row=2, column=0)
    tk.Radiobutton(root, text="Intersección", variable=op_var, value='intersect').grid(row=2, column=1, sticky='w')

    tk.Button(root, text="Calcular", command=calcular_conjunto).grid(row=3, column=0, pady=10)
    tk.Button(root, text="Cerrar", command=cerrar).grid(row=3, column=1, pady=10, sticky='w')

    resultado_var = tk.StringVar()
    tk.Label(root, text="Resultado:").grid(row=4, column=0, sticky='e')
    tk.Entry(root, textvariable=resultado_var, width=30, state='readonly').grid(row=4, column=1)

    entry_a.insert(0, "1,2,3")
    entry_b.insert(0, "2,3,4")

    if owns_root:
        root.mainloop()

if __name__ == "__main__":
    open_conjuntos()
