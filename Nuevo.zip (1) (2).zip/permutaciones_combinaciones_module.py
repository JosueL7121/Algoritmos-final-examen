import tkinter as tk
from tkinter import messagebox
import math

def open_combos(parent=None):
    owns_root = parent is None
    root = tk.Tk() if owns_root else tk.Toplevel(parent)
    if owns_root:
        root.title("Permutaciones y Combinaciones")
    else:
        root.title("Permutaciones/Combinaciones")

    root.geometry("450x300")

    def calcular():
        try:
            n = int(entry_n.get())
            r = int(entry_r.get())
        except ValueError:
            messagebox.showerror("Error", "Introduce valores enteros válidos para n y r.")
            return
        if n < 0 or r < 0:
            messagebox.showerror("Error", "n y r deben ser mayores o iguales a cero.")
            return
        opcion = opcion_var.get()
        try:
            if opcion == "perm_simple":
                if r > n:
                    messagebox.showerror("Error", "r no puede ser mayor que n para permutación simple.")
                    return
                res = math.factorial(n) // math.factorial(n - r)
            elif opcion == "perm_repet":
                res = n ** r
            elif opcion == "comb_simple":
                if r > n:
                    messagebox.showerror("Error", "r no puede ser mayor que n para combinación simple.")
                    return
                res = math.factorial(n) // (math.factorial(r) * math.factorial(n - r))
            elif opcion == "comb_repet":
                if n == 0 and r > 0:
                    messagebox.showerror("Error", "n debe ser al menos 1 para combinación con repetición cuando r>0.")
                    return
                res = math.factorial(n + r - 1) // (math.factorial(r) * math.factorial(n - 1))
            else:
                res = 0
        except Exception as e:
            messagebox.showerror("Error", f"Error en cálculo: {e}")
            return
        resultado_var.set(str(res))

    def cerrar():
        root.destroy()

    tk.Label(root, text="n:").grid(row=0, column=0, sticky='e', pady=5)
    entry_n = tk.Entry(root, width=15); entry_n.grid(row=0, column=1)
    tk.Label(root, text="r:").grid(row=1, column=0, sticky='e', pady=5)
    entry_r = tk.Entry(root, width=15); entry_r.grid(row=1, column=1)

    opcion_var = tk.StringVar(value="perm_simple")
    tk.Radiobutton(root, text="Permutación sin repetición", variable=opcion_var, value="perm_simple").grid(row=2, column=0, columnspan=2, sticky='w')
    tk.Radiobutton(root, text="Permutación con repetición", variable=opcion_var, value="perm_repet").grid(row=3, column=0, columnspan=2, sticky='w')
    tk.Radiobutton(root, text="Combinación sin repetición", variable=opcion_var, value="comb_simple").grid(row=4, column=0, columnspan=2, sticky='w')
    tk.Radiobutton(root, text="Combinación con repetición", variable=opcion_var, value="comb_repet").grid(row=5, column=0, columnspan=2, sticky='w')

    tk.Button(root, text="Calcular", command=calcular).grid(row=6, column=0, pady=10)
    tk.Button(root, text="Cerrar", command=cerrar).grid(row=6, column=1, pady=10, sticky='w')

    resultado_var = tk.StringVar()
    tk.Label(root, text="Resultado:").grid(row=7, column=0, sticky='e')
    tk.Entry(root, textvariable=resultado_var, width=20, state='readonly').grid(row=7, column=1)

    entry_n.insert(0, "5")
    entry_r.insert(0, "3")

    if owns_root:
        root.mainloop()

if __name__ == "__main__":
    open_combos()
