import tkinter as tk
from tkinter import messagebox
import os
import sys
import subprocess

#Colores base
COLOR_FONDO = "#F8FAFF"
COLOR_TITULO = "#2C3E50"
COLOR_BOTON1 = "#EAF1FF"
COLOR_BOTON2 = "#D8ECFF"
COLOR_BOTON3 = "#E9F7F6"

#Ventana principal
ventana = tk.Tk()
ventana.title("Menú Principal")
ventana.geometry("500x500")
ventana.config(bg=COLOR_FONDO)
ventana.resizable(False, False)

#Función para abrir archivos Python
def abrir_archivo(nombre_archivo):
    ruta_completa = os.path.abspath(nombre_archivo)  # Ayuda a encontrar el archivo
    if os.path.exists(ruta_completa):
        try:
            subprocess.Popen([sys.executable, ruta_completa])
        except Exception as e:
            messagebox.showerror("Error al abrir", f"No se pudo abrir el archivo:\n{e}") #mensajes error si no identifica archivo
    else:
        messagebox.showerror("Archivo no encontrado", f"No se encontró el archivo:\n{ruta_completa}")

#Funciones de abrir archivo
def abrir_algebra():
    abrir_archivo("algebra.py")

def abrir_discreta():
    abrir_archivo("discreta.py")

def abrir_tienda():
    abrir_archivo("tienda.py")

def salir():
    ventana.destroy()

#Título
titulo = tk.Label(
    ventana,
    text="Menú Principal",
    font=("Arial", 24, "bold"),
    bg=COLOR_FONDO,
    fg=COLOR_TITULO
)
titulo.pack(pady=20)

#Decoracion de las opciones del menu(tipo de letra o tamaño u color)
frame = tk.Frame(ventana, bg=COLOR_FONDO)
frame.pack(pady=10)

def crear_opcion(parent, color, icono, titulo, descripcion, comando):
    box = tk.Frame(parent, bg=color, bd=1, relief="solid", padx=15, pady=10)
    box.pack(pady=10, fill="x", padx=40)

    icon_label = tk.Label(box, text=icono, font=("Arial", 20), bg=color, fg="#2C3E50")
    icon_label.grid(row=0, column=0, rowspan=2, padx=10)

    titulo_label = tk.Label(box, text=titulo, font=("Arial", 14, "bold"), bg=color, fg="#2C3E50", cursor="hand2")
    titulo_label.grid(row=0, column=1, sticky="w")

    desc_label = tk.Label(box, text=descripcion, font=("Arial", 10), bg=color, fg="#34495E", cursor="hand2")
    desc_label.grid(row=1, column=1, sticky="w")

    for widget in (box, icon_label, titulo_label, desc_label):
        widget.bind("<Button-1>", lambda e, cmd=comando: cmd())

#Detalles del menú
crear_opcion(frame, COLOR_BOTON1, "📘", "Álgebra lineal", "Resuelve sistemas de ecuaciones, matrices y más.", abrir_algebra)
crear_opcion(frame, COLOR_BOTON2, "📊", "Matemática discreta", "Practica combinatoria y lógica booleana.", abrir_discreta)
crear_opcion(frame, COLOR_BOTON3, "🛒", "Tienda", "Simula una tienda con cálculos de precios y stock.", abrir_tienda)

#Botón de salida
btn_salir = tk.Button(
    ventana,
    text="Salir",
    font=("Arial", 12, "bold"),
    bg="#E74C3C",
    fg="white",
    width=15,
    command=salir
)
btn_salir.pack(pady=20)

ventana.mainloop()