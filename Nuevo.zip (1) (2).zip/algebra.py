import tkinter as tk
from tkinter import messagebox

def obtener_matriz(entradas, n):
    matriz = []
    for i in range(n):
        fila = []
        for j in range(n):
            try:
                valor = float(entradas[i][j].get())
            except ValueError:
                messagebox.showerror("Error", "Por favor ingrese solo números.")
                return None
            fila.append(valor)
        matriz.append(fila)
    return matriz

def inversa_gauss_jordan(matriz):
    n = len(matriz)
    A = [fila[:] for fila in matriz]
    I = [[float(i == j) for j in range(n)] for i in range(n)]
    for i in range(n):
        if A[i][i] == 0:
            for k in range(i + 1, n):
                if A[k][i] != 0:
                    A[i], A[k] = A[k], A[i]
                    I[i], I[k] = I[k], I[i]
                    break
            else:
                messagebox.showinfo("Resultado", "La matriz no tiene inversa (determinante = 0).")
                return None
        pivote = A[i][i]
        for j in range(n):
            A[i][j] /= pivote
            I[i][j] /= pivote
        for k in range(n):
            if k != i:
                factor = A[k][i]
                for j in range(n):
                    A[k][j] -= factor * A[i][j]
                    I[k][j] -= factor * I[i][j]
    return I

def multiplicar_matrices(A, B):
    n = len(A)
    C = [[0 for _ in range(n)] for _ in range(n)]
    for i in range(n):
        for j in range(n):
            for k in range(n):
                C[i][j] += A[i][k] * B[k][j]
    return C

def determinante(m):
    n = len(m)
    if n == 1:
        return m[0][0]
    if n == 2:
        return m[0][0] * m[1][1] - m[0][1] * m[1][0]
    det = 0
    for c in range(n):
        menor = [fila[:c] + fila[c + 1:] for fila in m[1:]]
        det += ((-1) ** c) * m[0][c] * determinante(menor)
    return det

def resolver_cramer(A, b):
    detA = determinante(A)
    if detA == 0:
        return "Sin solución o infinitas soluciones (det = 0)."
    n = len(A)
    soluciones = []
    for i in range(n):
        Ai = [fila[:] for fila in A]
        for j in range(n):
            Ai[j][i] = b[j]
        soluciones.append(determinante(Ai) / detA)
    return soluciones

def resolver_gauss_jordan(A, b):
    n = len(A)
    for i in range(n):
        A[i].append(b[i])
    for i in range(n):
        if A[i][i] == 0:
            for k in range(i + 1, n):
                if A[k][i] != 0:
                    A[i], A[k] = A[k], A[i]
                    break
            else:
                return "Sin solución o infinitas soluciones."
        pivote = A[i][i]
        for j in range(i, n + 1):
            A[i][j] /= pivote
        for k in range(n):
            if k != i:
                factor = A[k][i]
                for j in range(i, n + 1):
                    A[k][j] -= factor * A[i][j]
    return [A[i][-1] for i in range(n)]

def mostrar_matriz(matriz):
    return "\n".join(["\t".join([f"{num:.2f}" for num in fila]) for fila in matriz])

def calcular_inversa():
    matriz = obtener_matriz(entradas_matriz1, n_var.get())
    if matriz:
        inv = inversa_gauss_jordan(matriz)
        if inv:
            messagebox.showinfo("Matriz Inversa", mostrar_matriz(inv))

def calcular_multiplicacion():
    A = obtener_matriz(entradas_matriz1, n_var.get())
    B = obtener_matriz(entradas_matriz2, n_var.get())
    if A and B:
        C = multiplicar_matrices(A, B)
        messagebox.showinfo("Resultado", mostrar_matriz(C))

def resolver_sistema():
    A = obtener_matriz(entradas_matriz1, n_var.get())
    if not A:
        return
    b = []
    for i in range(n_var.get()):
        try:
            b.append(float(entradas_b[i].get()))
        except ValueError:
            messagebox.showerror("Error", "Ingrese solo números en los términos independientes.")
            return
    metodo = metodo_var.get()
    if metodo == "Cramer":
        resultado = resolver_cramer(A, b)
    else:
        resultado = resolver_gauss_jordan(A, b)
    if isinstance(resultado, list):
        texto = "\n".join([f"x{i+1} = {val:.2f}" for i, val in enumerate(resultado)])
        messagebox.showinfo("Solución del Sistema", texto)
    else:
        messagebox.showinfo("Resultado", resultado)

root = tk.Tk()
root.title("Proyecto de Álgebra Lineal")
root.geometry("750x750")
root.config(bg="#f0f0f0")

tk.Label(root, text="Tamaño de la matriz (n x n):", bg="#f0f0f0", font=("Arial", 11, "bold")).pack()
n_var = tk.IntVar(value=2)
tk.Spinbox(root, from_=2, to=4, textvariable=n_var, width=5, font=("Arial", 11)).pack(pady=5)

def crear_entradas_matriz():
    for widget in frame_matriz1.winfo_children():
        widget.destroy()
    for widget in frame_matriz2.winfo_children():
        widget.destroy()
    for widget in frame_b.winfo_children():
        widget.destroy()
    n = n_var.get()
    global entradas_matriz1, entradas_matriz2, entradas_b
    entradas_matriz1 = [[tk.Entry(frame_matriz1, width=6, font=("Arial", 11), justify="center") for _ in range(n)] for _ in range(n)]
    entradas_matriz2 = [[tk.Entry(frame_matriz2, width=6, font=("Arial", 11), justify="center") for _ in range(n)] for _ in range(n)]
    entradas_b = [tk.Entry(frame_b, width=6, font=("Arial", 11), justify="center") for _ in range(n)]
    for i in range(n):
        for j in range(n):
            entradas_matriz1[i][j].grid(row=i, column=j, padx=3, pady=3)
            entradas_matriz2[i][j].grid(row=i, column=j, padx=3, pady=3)
        entradas_b[i].grid(row=i, column=0, padx=3, pady=3)

frame_matriz1 = tk.LabelFrame(root, text="Matriz A", bg="#f0f0f0", font=("Arial", 11, "bold"))
frame_matriz1.pack(pady=10)
frame_matriz2 = tk.LabelFrame(root, text="Matriz B", bg="#f0f0f0", font=("Arial", 11, "bold"))
frame_matriz2.pack(pady=10)
frame_b = tk.LabelFrame(root, text="Vector b", bg="#f0f0f0", font=("Arial", 11, "bold"))
frame_b.pack(pady=10)

tk.Button(root, text="Actualizar Tamaño", command=crear_entradas_matriz, bg="#0078D7", fg="white", font=("Arial", 11, "bold"), relief="flat", width=20).pack(pady=5)

metodo_var = tk.StringVar(value="Cramer")
tk.Label(root, text="Método para resolver sistemas:", bg="#f0f0f0", font=("Arial", 11, "bold")).pack()
tk.Radiobutton(root, text="Cramer", variable=metodo_var, value="Cramer", bg="#f0f0f0", font=("Arial", 11)).pack()
tk.Radiobutton(root, text="Gauss-Jordan", variable=metodo_var, value="Gauss", bg="#f0f0f0", font=("Arial", 11)).pack()

boton_frame = tk.Frame(root, bg="#f0f0f0")
boton_frame.pack(pady=15)

tk.Button(boton_frame, text="Encontrar Inversa", command=calcular_inversa, bg="#28A745", fg="white", font=("Arial", 11, "bold"), width=18, relief="flat").grid(row=0, column=0, padx=5, pady=5)
tk.Button(boton_frame, text="Multiplicar Matrices", command=calcular_multiplicacion, bg="#17A2B8", fg="white", font=("Arial", 11, "bold"), width=18, relief="flat").grid(row=0, column=1, padx=5, pady=5)
tk.Button(boton_frame, text="Resolver Sistema", command=resolver_sistema, bg="#FFC107", fg="black", font=("Arial", 11, "bold"), width=18, relief="flat").grid(row=0, column=2, padx=5, pady=5)

crear_entradas_matriz()
root.mainloop()
