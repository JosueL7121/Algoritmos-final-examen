import tkinter as tk
from tkinter import messagebox
from openpyxl import Workbook, load_workbook
import os
def inicializar_excel():
    if not os.path.exists("Ventas.xlsx"):
        wb = Workbook()
        ws = wb.active
        ws.title = "Productos"
        ws.append(["Código", "Nombre", "Existencia", "Proveedor", "Precio"])       
        ws = wb.create_sheet("Clientes")
        ws.append(["Código", "Nombre", "Dirección"])       
        ws = wb.create_sheet("Ventas")
        ws.append(["Código Producto", "Código Cliente", "Cantidad", "Total"])      
        wb.save("Ventas.xlsx")
def listar_productos():
    wb = load_workbook("Ventas.xlsx")
    ws = wb["Productos"]
    v = tk.Toplevel()
    v.title("Productos")
    t = tk.Text(v, width=80, height=20)
    t.pack()
    for row in ws.iter_rows(values_only=True):
        t.insert(tk.END, "\t".join([str(x) for x in row]) + "\n")
def crear_producto():
    def guardar():
        codigo = e_cod.get()
        nombre = e_nom.get()
        existencia = e_exi.get()
        proveedor = e_prov.get()
        precio = e_pre.get()
        
        if not (codigo and nombre and existencia and proveedor and precio):
            messagebox.showerror("Error", "Todos los campos son obligatorios")
            return            
        try:
            existencia = int(existencia)
            precio = float(precio)
        except ValueError:
            messagebox.showerror("Error", "Existencia debe ser entero y precio numerico")
            return            
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Productos"]       
        for row in ws.iter_rows(min_row=2, values_only=True):
            if str(row[0]) == str(codigo):
                messagebox.showerror("Error", "Código duplicado")
                return               
        ws.append([codigo, nombre, existencia, proveedor, precio])
        wb.save("Ventas.xlsx")
        messagebox.showinfo("Éxito", "Producto guardado")
        v.destroy()       
    v = tk.Toplevel()
    v.title("Crear Producto")    
    tk.Label(v, text="Código:").pack()
    e_cod = tk.Entry(v)
    e_cod.pack() 
    tk.Label(v, text="Nombre:").pack()
    e_nom = tk.Entry(v)
    e_nom.pack()  
    tk.Label(v, text="Existencia:").pack()
    e_exi = tk.Entry(v)
    e_exi.pack()
    tk.Label(v, text="Proveedor:").pack()
    e_prov = tk.Entry(v)
    e_prov.pack() 
    tk.Label(v, text="Precio:").pack()
    e_pre = tk.Entry(v)
    e_pre.pack()   
    tk.Button(v, text="Guardar", command=guardar).pack(pady=10)
def actualizar_producto():
    def buscar():
        codigo = e_bus.get()
        if not codigo:
            messagebox.showerror("Error", "Ingrese código")
            return
            
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Productos"]
        
        for row in ws.iter_rows(min_row=2):
            if str(row[0].value) == codigo:
                e_cod.delete(0, tk.END)
                e_nom.delete(0, tk.END)
                e_exi.delete(0, tk.END)
                e_prov.delete(0, tk.END)
                e_pre.delete(0, tk.END)
                e_cod.insert(0, row[0].value)
                e_nom.insert(0, row[1].value)
                e_exi.insert(0, row[2].value)
                e_prov.insert(0, row[3].value)
                e_pre.insert(0, row[4].value)
                return  
        messagebox.showinfo("Info", "Producto no encontrado")   
    def guardar():
        codigo = e_cod.get()
        nombre = e_nom.get()
        existencia = e_exi.get()
        proveedor = e_prov.get()
        precio = e_pre.get()
        if not (codigo and nombre and existencia and proveedor and precio):
            messagebox.showerror("Error", "Complete todos los campos")
            return
        try:
            existencia = int(existencia)
            precio = float(precio)
        except ValueError:
            messagebox.showerror("Error", "Existencia debe ser entero y precio numérico")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Productos"]
        for row in ws.iter_rows(min_row=2):
            if str(row[0].value) == codigo:
                row[1].value = nombre
                row[2].value = existencia
                row[3].value = proveedor 
                row[4].value = precio
                wb.save("Ventas.xlsx")
                messagebox.showinfo("Éxito", "Producto actualizado")
                v.destroy()
                return
        messagebox.showerror("Error", "Producto no encontrado")
    v = tk.Toplevel()
    v.title("Actualizar Producto")
    tk.Label(v, text="Buscar por código:").pack()
    e_bus = tk.Entry(v)
    e_bus.pack()
    tk.Button(v, text="Buscar", command=buscar).pack()
    tk.Label(v, text="Código:").pack()
    e_cod = tk.Entry(v)
    e_cod.pack()
    tk.Label(v, text="Nombre:").pack()
    e_nom = tk.Entry(v)
    e_nom.pack()
    tk.Label(v, text="Existencia:").pack()
    e_exi = tk.Entry(v)
    e_exi.pack()
    tk.Label(v, text="Proveedor:").pack()
    e_prov = tk.Entry(v)
    e_prov.pack()
    tk.Label(v, text="Precio:").pack()
    e_pre = tk.Entry(v)
    e_pre.pack()
    tk.Button(v, text="Guardar", command=guardar).pack(pady=10)
def editar_existencia_producto():
    def buscar():
        codigo = entry_buscar.get()
        if not codigo:
            messagebox.showerror("Error", "Ingrese código para buscar.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["productos"]
        for r in ws.iter_rows(min_row=2):
            if str(r[0].value) == codigo:
                entry_existencia.delete(0, tk.END)
                entry_existencia.insert(0, r[2].value)
                return
        messagebox.showinfo("Info", "Producto no encontrado.")

    def guardar():
        codigo = entry_buscar.get()
        nueva = entry_existencia.get()
        try:
            nueva = int(nueva)
        except ValueError:
            messagebox.showerror("Error", "Existencia debe ser entero.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Productos"]
        for r in ws.iter_rows(min_row=2):
            if str(r[0].value) == codigo:
                r[2].value = nueva
                wb.save("Ventas.xlsx")
                messagebox.showinfo("Éxito", "Existencia actualizada.")
                ventana.destroy()
                return
        messagebox.showerror("Error", "Producto no encontrado.")

    ventana = tk.Toplevel()
    ventana.title("ditar Existencia")
    tk.Label(ventana, text="Código:").pack()
    entry_buscar = tk.Entry(ventana)
    entry_buscar.pack()
    tk.Button(ventana, text="Buscar", command=buscar).pack(pady=5)
    tk.Label(ventana, text="Nueva existencia:").pack()
    entry_existencia = tk.Entry(ventana)
    entry_existencia.pack()
    tk.Button(ventana, text="Guardar", command=guardar).pack(pady=10)
def eliminar_producto():
    def eliminar():
        codigo = e_cod.get()
        if not codigo:
            messagebox.showerror("Error", "Ingrese código")
            return
            
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Productos"]
        
        for row in ws.iter_rows(min_row=2):
            if str(row[0].value) == codigo:
                ws.delete_rows(row[0].row, 1)
                wb.save("Ventas.xlsx")
                messagebox.showinfo("Éxito", "Producto eliminado")
                v.destroy()
                return
                
        messagebox.showerror("Error", "Producto no encontrado")
        
    v = tk.Toplevel()
    v.title("Eliminar Producto")
    
    tk.Label(v, text="Código:").pack()
    e_cod = tk.Entry(v)
    e_cod.pack()
    
    tk.Button(v, text="Eliminar", command=eliminar).pack(pady=10)
def listar_clientes():
    wb = load_workbook("Ventas.xlsx")
    ws = wb["Clientes"]
    ventana = tk.Toplevel()
    ventana.title("Lista de Clientes")
    text = tk.Text(ventana, width=80, height=20)
    text.pack()
    for row in ws.iter_rows(values_only=True):
        text.insert(tk.END, "\t".join([str(x) for x in row]) + "\n")
def crear_cliente():
    def guardar():
        codigo = entry_codigo.get()
        nombre = entry_nombre.get()
        direccion = entry_direccion.get()
        if not (codigo and nombre and direccion):
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Clientes"]
        for row in ws.iter_rows(min_row=2, values_only=True):
            if str(row[0]) == codigo:
                messagebox.showerror("Error", "Ya existe un cliente con ese código.")
                return
        ws.append([codigo, nombre, direccion])
        wb.save("Ventas.xlsx")
        messagebox.showinfo("Éxito", "Cliente creado.")
        ventana.destroy()

    ventana = tk.Toplevel()
    ventana.title("Crear Cliente")
    tk.Label(ventana, text="Código:").pack()
    entry_codigo = tk.Entry(ventana)
    entry_codigo.pack()
    tk.Label(ventana, text="Nombre:").pack()
    entry_nombre = tk.Entry(ventana)
    entry_nombre.pack()
    tk.Label(ventana, text="Dirección:").pack()
    entry_direccion = tk.Entry(ventana)
    entry_direccion.pack()
    tk.Button(ventana, text="Guardar", command=guardar).pack(pady=10)
def editar_cliente():
    def buscar():
        codigo = entry_buscar.get()
        if not codigo:
            messagebox.showerror("Error", "Ingrese código.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Clientes"]
        for r in ws.iter_rows(min_row=2):
            if str(r[0].value) == codigo:
                entry_codigo.delete(0, tk.END)
                entry_nombre.delete(0, tk.END)
                entry_direccion.delete(0, tk.END)
                entry_codigo.insert(0, r[0].value)
                entry_nombre.insert(0, r[1].value)
                entry_direccion.insert(0, r[2].value)
                return
        messagebox.showinfo("Info", "Cliente no encontrado.")
    def guardar():
        codigo = entry_codigo.get()
        nombre = entry_nombre.get()
        direccion = entry_direccion.get()
        if not (codigo and nombre and direccion):
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Clientes"]
        for r in ws.iter_rows(min_row=2):
            if str(r[0].value) == codigo:
                r[1].value = nombre
                r[2].value = direccion
                wb.save("Ventas.xlsx")
                messagebox.showinfo("Éxito", "Cliente actualizado.")
                ventana.destroy()
                return
        messagebox.showerror("Error", "Cliente no encontrado.")

    ventana = tk.Toplevel()
    ventana.title("Editar Cliente")
    tk.Label(ventana, text="Código a buscar:").pack()
    entry_buscar = tk.Entry(ventana)
    entry_buscar.pack()
    tk.Button(ventana, text="Buscar", command=buscar).pack(pady=5)
    tk.Label(ventana, text="Código:").pack()
    entry_codigo = tk.Entry(ventana)
    entry_codigo.pack()
    tk.Label(ventana, text="Nombre:").pack()
    entry_nombre = tk.Entry(ventana)
    entry_nombre.pack()
    tk.Label(ventana, text="Dirección:").pack()
    entry_direccion = tk.Entry(ventana)
    entry_direccion.pack()
    tk.Button(ventana, text="Guardar cambios", command=guardar).pack(pady=10)
def eliminar_cliente():
    def eliminar():
        codigo = entry_codigo.get()
        if not codigo:
            messagebox.showerror("Error", "Ingrese código.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Clientes"]
        for row in ws.iter_rows(min_row=2):
            if str(row[0].value) == codigo:
                ws.delete_rows(row[0].row, 1)
                wb.save("Ventas.xlsx")
                messagebox.showinfo("Éxito", "Cliente eliminado.")
                ventana.destroy()
                return
        messagebox.showerror("Error", "Cliente no encontrado.")
    ventana = tk.Toplevel()
    ventana.title("Eliminar Cliente")
    tk.Label(ventana, text="Código:").pack()
    entry_codigo = tk.Entry(ventana)
    entry_codigo.pack()
    tk.Button(ventana, text="Eliminar", command=eliminar).pack(pady=10)
def listar_ventas():
    wb = load_workbook("Ventas.xlsx")
    ws = wb["Ventas"]
    ventana = tk.Toplevel()
    ventana.title("Lista de Ventas")
    text = tk.Text(ventana, width=80, height=20)
    text.pack()
    for row in ws.iter_rows(values_only=True):
        text.insert(tk.END, "\t".join([str(x) for x in row]) + "\n")
def crear_venta():
    def guardar():
        codigo_producto = entry_producto.get()
        codigo_cliente = entry_cliente.get()
        cantidad = entry_cantidad.get()
        if not (codigo_producto and codigo_cliente and cantidad):
            messagebox.showerror("Error", "Todos los campos son obligatorios.")
            return
        try:
            cantidad = int(cantidad)
        except ValueError:
            messagebox.showerror("Error", "Cantidad debe ser entero.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws_prod = wb["Productos"]
        ws_cli = wb["Clientes"]
        ws_ven = wb["Ventas"]
        prod_row = None
        for r in ws_prod.iter_rows(min_row=2):
            if str(r[0].value) == codigo_producto:
                prod_row = r
                break
        if not prod_row:
            messagebox.showerror("Error", "Producto no encontrado.")
            return
        if prod_row[2].value is None or prod_row[2].value < cantidad:
            messagebox.showerror("Error", "No hay existencia suficiente.")
            return
        cli_found = False
        for r in ws_cli.iter_rows(min_row=2, values_only=True):
            if str(r[0]) == codigo_cliente:
                cli_found = True
                break
        if not cli_found:
            messagebox.showerror("Error", "Cliente no encontrado.")
            return
        total = cantidad * float(prod_row[4].value)
        ws_ven.append([codigo_producto, codigo_cliente, cantidad, total])
        prod_row[2].value = prod_row[2].value - cantidad
        wb.save("Ventas.xlsx")
        messagebox.showinfo("Éxito", f"Venta registrada. Total: {total}")
        ventana.destroy()

    ventana = tk.Toplevel()
    ventana.title("Crear Venta")
    tk.Label(ventana, text="Código de producto:").pack()
    entry_producto = tk.Entry(ventana)
    entry_producto.pack()
    tk.Label(ventana, text="Código de cliente:").pack()
    entry_cliente = tk.Entry(ventana)
    entry_cliente.pack()
    tk.Label(ventana, text="Cantidad:").pack()
    entry_cantidad = tk.Entry(ventana)
    entry_cantidad.pack()
    tk.Button(ventana, text="Registrar venta", command=guardar).pack(pady=10)
def anular_venta():
    def anular():
        fila = entry_fila.get()
        if not fila:
            messagebox.showerror("Error", "Ingrese número de fila (debe corresponder a la fila en el Excel, comenzando en 2)")
            return
        try:
            fila = int(fila)
        except ValueError:
            messagebox.showerror("Error", "Fila debe ser un número.")
            return
        wb = load_workbook("Ventas.xlsx")
        ws = wb["Ventas"]
        maxr = ws.max_row
        if fila < 2 or fila > maxr:
            messagebox.showerror("Error", "Número de fila inválido.")
            return
        codigo_producto = ws.cell(row=fila, column=1).value
        cantidad = ws.cell(row=fila, column=3).value
        if codigo_producto is None:
            messagebox.showerror("Error", "Fila vacía.")
            return
        ws_prod = wb["Productos"]
        for r in ws_prod.iter_rows(min_row=2):
            if str(r[0].value) == str(codigo_producto):
                if r[2].value is None:
                    r[2].value = cantidad
                else:
                    r[2].value = r[2].value + cantidad
                break
        ws.delete_rows(fila, 1)
        wb.save("Ventas.xlsx")
        messagebox.showinfo("Éxito", "Venta anulada y stock restaurado.")
        ventana.destroy()

    ventana = tk.Toplevel()
    ventana.title("Anular Venta")
    tk.Label(ventana, text="Número de fila en Excel (ej: 2 para la primera venta)").pack()
    entry_fila = tk.Entry(ventana)
    entry_fila.pack()
    tk.Button(ventana, text="Anular", command=anular).pack(pady=10)
def reporte_ventas_por_cliente():
    wb = load_workbook("Ventas.xlsx")
    ws_ven = wb["Ventas"]
    totals = {}
    for r in ws_ven.iter_rows(min_row=2, values_only=True):
        if not r[1]:
            continue
        cliente = str(r[1])
        total = float(r[3]) if r[3] else 0
        totals[cliente] = totals.get(cliente, 0) + total
    from openpyxl import Workbook as Wb
    rb = Wb()
    rws = rb.active
    rws.title = "VentasPorCliente"
    rws.append(["Código Cliente", "Total Ventas"])
    for c, t in totals.items():
        rws.append([c, t])
    nombre = "Reporte_Ventas_por_Cliente.xlsx"
    rb.save(nombre)
    messagebox.showinfo("reporte generado", f"Reporte guardado como {nombre}")
    if messagebox.askyesno("Enviar", "¿Desea enviar el reporte por correo?"):
        enviar_correo_adjuntos([nombre])
def reporte_ventas_por_producto():
    wb = load_workbook("Ventas.xlsx")
    ws_ven = wb["Ventas"]
    totals = {}
    for r in ws_ven.iter_rows(min_row=2, values_only=True):
        if not r[0]:
            continue
        prod = str(r[0])
        total = float(r[3]) if r[3] else 0
        totals[prod] = totals.get(prod, 0) + total
    from openpyxl import Workbook as Wb
    rb = Wb()
    rws = rb.active
    rws.title = "VentasPorProducto"
    rws.append(["Código Producto", "Total Ventas"])
    for p, t in totals.items():
        rws.append([p, t])
    nombre = "Reporte_Ventas_por_Producto.xlsx"
    rb.save(nombre)
    messagebox.showinfo("Reporte generado", f"Reporte guardado como {nombre}")
    if messagebox.askyesno("Enviar", "¿Desea enviar el reporte por correo?"):
        enviar_correo_adjuntos([nombre])
def enviar_correo_adjuntos(archivos):
    import smtplib
    from email.message import EmailMessage
    from email.utils import make_msgid
    from email import encoders
    from email.mime.base import MIMEBase
    ventana = tk.Toplevel()
    ventana.title("Enviar correo")
    tk.Label(ventana, text="Servidor SMTP (ej: smtp.gmail.com)").pack()
    entry_smtp = tk.Entry(ventana)
    entry_smtp.pack()
    tk.Label(ventana, text="Puerto (ej: 587)").pack()
    entry_puerto = tk.Entry(ventana)
    entry_puerto.pack()
    tk.Label(ventana, text="Usuario (correo)").pack()
    entry_usuario = tk.Entry(ventana)
    entry_usuario.pack()
    tk.Label(ventana, text="Contraseña").pack()
    entry_pass = tk.Entry(ventana, show='*')
    entry_pass.pack()
    tk.Label(ventana, text="Destinatario").pack()
    entry_dest = tk.Entry(ventana)
    entry_dest.pack()

    def enviar():
        smtp_server = entry_smtp.get()
        puerto = entry_puerto.get()
        usuario = entry_usuario.get()
        clave = entry_pass.get()
        destino = entry_dest.get()
        if not (smtp_server and puerto and usuario and clave and destino):
            messagebox.showerror("Error", "Complete todos los campos de correo.")
            return
        try:
            puerto = int(puerto)
        except ValueError:
            messagebox.showerror("Error", "Puerto inválido.")
            return
        msg = EmailMessage()
        msg['Subject'] = 'Reporte'
        msg['From'] = usuario
        msg['To'] = destino
        msg.set_content('Adjunto el/los reporte(s).')
        for ruta in archivos:
            with open(ruta, 'rb') as f:
                data = f.read()
            maintype = 'application'
            subtype = 'octet-stream'
            msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=os.path.basename(ruta))
        try:
            with smtplib.SMTP(smtp_server, puerto) as server:
                server.starttls()
                server.login(usuario, clave)
                server.send_message(msg)
            messagebox.showinfo("Enviado", "Correo enviado correctamente.")
            ventana.destroy()
        except Exception as e:
            messagebox.showerror("Error", f"Fallo al enviar correo: {e}")

    tk.Button(ventana, text="Enviar", command=enviar).pack(pady=10)
def inicializar_excel():
    if not os.path.exists("Ventas.xlsx"):
        wb = Workbook()
        ws_productos = wb.active
        ws_productos.title = "Productos"
        ws_productos.append(["Código", "Nombre", "Existencia", "Proveedor", "Precio"])
        ws_clientes = wb.create_sheet(title="Clientes")
        ws_clientes.append(["Código", "Nombre", "Dirección"])
        ws_ventas = wb.create_sheet(title="Ventas")
        ws_ventas.append(["Código de producto", "Código del cliente", "Cantidad", "Total"])
        wb.save("Ventas.xlsx")
def main():
    inicializar_excel()
    root = tk.Tk()
    root.title("Sistema de ventas algoritmos 2025")
    root.geometry("720x480")
    menu_bar = tk.Menu(root)
    inventario_menu = tk.Menu(menu_bar, tearoff=0)
    inventario_menu.add_command(label="Listar productos", command=listar_productos)
    inventario_menu.add_command(label="Crear producto", command=crear_producto)
    inventario_menu.add_command(label="Actualizar producto", command=actualizar_producto)
    inventario_menu.add_command(label="Editar existencia", command=editar_existencia_producto)
    inventario_menu.add_command(label="Eliminar producto", command=eliminar_producto)
    menu_bar.add_cascade(label="Inventario", menu=inventario_menu)
    clientes_menu = tk.Menu(menu_bar, tearoff=0)
    clientes_menu.add_command(label="Listar clientes", command=listar_clientes)
    clientes_menu.add_command(label="Crear cliente", command=crear_cliente)
    clientes_menu.add_command(label="Editar cliente", command=editar_cliente)
    clientes_menu.add_command(label="Eliminar cliente", command=eliminar_cliente)
    menu_bar.add_cascade(label="Clientes", menu=clientes_menu)
    ventas_menu = tk.Menu(menu_bar, tearoff=0)
    ventas_menu.add_command(label="Listar ventas", command=listar_ventas)
    ventas_menu.add_command(label="Crear venta", command=crear_venta)
    ventas_menu.add_command(label="Anular venta", command=anular_venta)
    menu_bar.add_cascade(label="Ventas", menu=ventas_menu)
    reportes_menu = tk.Menu(menu_bar, tearoff=0)
    reportes_menu.add_command(label="Ventas por cliente", command=reporte_ventas_por_cliente)
    reportes_menu.add_command(label="Ventas por producto", command=reporte_ventas_por_producto)
    menu_bar.add_cascade(label="Reportes", menu=reportes_menu)
    root.config(menu=menu_bar)
    root.mainloop()
if __name__ == "__main__":
    main()