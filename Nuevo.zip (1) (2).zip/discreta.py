import tkinter as tk
import mcd_module    
import conjuntos_module
import permutaciones_combinaciones_module

def main():
    root = tk.Tk()
    root.title("Lanzador - MCD / Conjuntos / Combinaciones")
    root.geometry("360x220")

    tk.Label(root, text="Seleccione el módulo que desea abrir:", pady=10).pack()

    btn_frame = tk.Frame(root)
    btn_frame.pack(pady=8)

    tk.Button(btn_frame, text="Abrir MCD", width=25, command=lambda: mcd_module.open_mcd(parent=root)).pack(pady=4)
    tk.Button(btn_frame, text="Abrir Conjuntos", width=25, command=lambda: conjuntos_module.open_conjuntos(parent=root)).pack(pady=4)
    tk.Button(btn_frame, text="Abrir Perm./Comb.", width=25, command=lambda: permutaciones_combinaciones_module.open_combos(parent=root)).pack(pady=4)

    tk.Button(root, text="Salir", width=20, command=root.destroy).pack(pady=10)

    root.mainloop()

if __name__ == "__main__":
    main()
