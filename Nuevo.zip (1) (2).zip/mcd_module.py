import tkinter as tk
from tkinter import messagebox

def euclides(a, b):
    while b != 0:
        a, b = b, a % b
    return a

def open_mcd(parent=None):
    owns_root = parent is None
    root = tk.Tk() if owns_root else tk.Toplevel(parent)
    if owns_root:
        root.title("MCD")
    else:
        root.title("MCD")

    root.geometry("400x180")

    def calcular_mcd():
        try:
            num1 = int(entry_a.get())
            num2 = int(entry_b.get())
        except ValueError:
            messagebox.showerror("Error", "Introduce números enteros válidos.")
            return
        if num1 <= 0 or num2 <= 0:
            messagebox.showerror("Error", "Introduce números mayores que cero.")
            return
        mcd = euclides(num1, num2)
        resultado_var.set(str(mcd))

    def cerrar():
        if owns_root:
            root.destroy()
        else:
            root.destroy()


    tk.Label(root, text="Número A:").grid(row=0, column=0, pady=10, padx=5, sticky='e')
    entry_a = tk.Entry(root, width=20); entry_a.grid(row=0, column=1)
    tk.Label(root, text="Número B:").grid(row=1, column=0, pady=10, padx=5, sticky='e')
    entry_b = tk.Entry(root, width=20); entry_b.grid(row=1, column=1)

    tk.Button(root, text="Calcular MCD", command=calcular_mcd).grid(row=2, column=0, pady=10)
    tk.Button(root, text="Cerrar", command=cerrar).grid(row=2, column=1, pady=10, sticky='w')

    resultado_var = tk.StringVar()
    tk.Label(root, text="MCD:").grid(row=3, column=0, sticky='e')
    tk.Entry(root, textvariable=resultado_var, width=20, state='readonly').grid(row=3, column=1)

    entry_a.insert(0, "252")
    entry_b.insert(0, "105")

    if owns_root:
        root.mainloop()

if __name__ == "__main__":
    open_mcd()
